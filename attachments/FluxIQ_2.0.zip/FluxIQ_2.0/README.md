# FluxIQ 2.0 — Urban Flood Intelligence

Standalone SIH-ready frontend prototype. Uses React 19.2, Vite 8.1 and MapLibre GL JS 6.7. Includes live Open-Meteo forecast/geocoding, rainfall accumulation, soil moisture, runoff indicators, a transparent flood-risk score, WebGL GIS map, NASA GPM IMERG/Worldview entry point, mobile UI, and explicit LIVE/DEGRADED/OPTIONAL data states.

## Run
Node.js 20+ recommended.

```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## GitHub Pages
Upload this project to a new GitHub repository. Build with `npm run build`, then deploy `dist` with GitHub Pages. No API key is required for the included demo APIs.

The official-gauge connection is intentionally marked OPTIONAL until a real municipal gauge feed is connected; the app does not fake a water-level sensor.
